//
//  CustomNavigationController.swift
//  Bawsala_Customer
//
//  Created by Siddhant on 31/12/18.
//  Copyright © 2018 Maktech. All rights reserved.
//

import UIKit

///
enum NavigationUIType {
    
    /// Set default navigaiton bar as per design
    case defaultUI
    /// Makes navigaiton bar clear and translucent
    case clearUI
}

///
class CustomNavigationController: UINavigationController {
    
    /// MARK: - Variables
    
    ///
    private let titleBlackColor = UIColor(red: 19/255, green: 19/255, blue: 21/255, alpha: 1.0)
    
    // MARK: - Life Cycle Methods
    
    ///
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        setupNavigationUI()
    }
    
    /// MARK: - SetupUI
    private func basicUISetup() {
        self.navigationBar.tintColor = titleBlackColor
        //self.navigationBar.backIndicatorImage = R.image.backArrow()
      //  self.navigationBar.backIndicatorTransitionMaskImage = R.image.backArrow()
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.titleTextAttributes = [.font: UIFont(name: "OpenSans-Regular", size: 20.0) ?? UIFont.systemFont(ofSize: 20.0), .foregroundColor: titleBlackColor] // For fonts, textcolor, letter spacing
        //, .kern: 1.43
    }
    
    ///
    func setupNavigationUI(type: NavigationUIType = .defaultUI) {
      //  DispatchQueue.main.async { [weak self] in
            
            if type == .defaultUI {
                self.view.backgroundColor = UIColor.white
                self.navigationBar.isTranslucent = false
            } else {
                self.navigationBar.isTranslucent = true
                self.view.backgroundColor = UIColor.clear
                self.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
            }
            self.basicUISetup()
      //  }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
