//
//  InbooksViewController.swift
//  UIDemo
//
//  Created by Siddhant Jain on 18/04/19.
//  Copyright © 2019 Siddhant. All rights reserved.
//

import UIKit

class InbooksTableViewCell: UITableViewCell {
    @IBOutlet weak var profileImageView: UIImageView?
    @IBOutlet weak var nameLabel: UILabel?

    @IBOutlet weak var descLabel: UILabel?
    @IBOutlet weak var timeLabel: UILabel?

}

class InbooksViewController: UIViewController {

    @IBOutlet weak var inTableView: UITableView!
    @IBAction func backTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    var desc = ["I'm a self-taught modern calligrapher who found respite in hand-lettering…", "Lisbon is full of street art but what the lovely Igor offers is local knowledge and …", "The description is accurate and the event was what I expected. I would  …", "Both delicious and fun. Jacob was informative and entertaining. Plus we ...", "We had so much fun and loved everything we made. Chef Jacob was …"]
    var name = ["Violet Mcdonalid", "Austin Griffin", "Sean Arnold", "Linda Flores", "Marcus Holmes"]
    var profiles = [UIImage(named: "p1"), UIImage(named: "p2"), UIImage(named: "p3"), UIImage(named: "p4"), UIImage(named: "p5")]
    var time = ["1h", "6h", "1d", "2w", "8w"]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        inTableView.tableFooterView = UIView()
        inTableView.estimatedRowHeight = 91
        inTableView.rowHeight = UITableView.automaticDimension
    }


    /*
     // MARK: - Navigation

     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */

}

extension InbooksViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChatViewController") else { return }
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension InbooksViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return desc.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "inbooksCell") as? InbooksTableViewCell else {
            return UITableViewCell()
        }
        cell.profileImageView?.image = profiles[indexPath.row]
        cell.nameLabel?.text = name[indexPath.row]
        cell.descLabel?.text = desc[indexPath.row]
        cell.timeLabel?.text = time[indexPath.row]
        return cell
    }
}


