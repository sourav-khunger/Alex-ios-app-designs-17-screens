//
//  LoginViewController.swift
//  UIDemo
//
//  Created by Siddhant Jain on 27/03/19.
//  Copyright © 2019 Siddhant. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    var attrs = [
        NSAttributedString.Key.font : UIFont(name: "OpenSans-Regular", size: 16.0) ?? UIFont.systemFont(ofSize: 16.0),
        NSAttributedString.Key.foregroundColor : UIColor.white,
        NSAttributedString.Key.underlineStyle : 1] as [NSAttributedString.Key : Any]

    var attributedString = NSMutableAttributedString(string:"")

    @IBOutlet weak var registerButton: UIButton!
    @IBAction func forgetPassword(_ sender: Any) {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPasswordViewController") else { return }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func loginTapped(_ sender: Any) {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "GetStartedViewController") else { return }
        self.navigationController?.pushViewController(vc, animated: true)

    }
    @IBAction func registerTapped(_ sender: Any) {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "RegisterViewController") else { return }
        self.navigationController?.pushViewController(vc, animated: true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let buttonTitleStr = NSMutableAttributedString(string:"Registrer deg!", attributes:attrs)
        attributedString.append(buttonTitleStr)
        registerButton.setAttributedTitle(attributedString, for: .normal)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
