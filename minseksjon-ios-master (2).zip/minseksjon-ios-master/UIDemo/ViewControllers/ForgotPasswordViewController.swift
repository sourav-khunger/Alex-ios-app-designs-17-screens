//
//  ForgotPasswordViewController.swift
//  UIDemo
//
//  Created by Siddhant Jain on 27/03/19.
//  Copyright © 2019 Siddhant. All rights reserved.
//

import UIKit

class ForgotPasswordViewController: UIViewController {

    var attrs = [
        NSAttributedString.Key.font : UIFont(name: "OpenSans-Regular", size: 16.0) ?? UIFont.systemFont(ofSize: 16.0),
        NSAttributedString.Key.foregroundColor : UIColor.white,
        NSAttributedString.Key.underlineStyle : 1] as [NSAttributedString.Key : Any]

    var attributedString = NSMutableAttributedString(string:"")
    
    @IBOutlet weak var loginButton: UIButton!

    @IBOutlet weak var registerButton: UIButton!

    @IBAction func forgotPasswordTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func loginTapped(_ sender: Any) {
        if navigationController?.viewControllers.last is LoginViewController { self.navigationController?.popViewController(animated: true)
        } else {
            guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") else { return }
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func registerTapped(_ sender: Any) {
        if navigationController?.viewControllers.last is RegisterViewController { self.navigationController?.popViewController(animated: true)
        } else {
            guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "RegisterViewController") else { return }
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let buttonTitleStr = NSMutableAttributedString(string:"Registrer deg!", attributes:attrs)
        attributedString.append(buttonTitleStr)
        registerButton.setAttributedTitle(attributedString, for: .normal)

        let buttonTitleStr2 = NSMutableAttributedString(string:"Logg inn", attributes:attrs)
        attributedString = NSMutableAttributedString(string:"")
        attributedString.append(buttonTitleStr2)
        loginButton.setAttributedTitle(attributedString, for: .normal)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
