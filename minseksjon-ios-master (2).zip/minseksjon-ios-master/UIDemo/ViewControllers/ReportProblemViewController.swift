//
//  ReportProblemViewController.swift
//  UIDemo
//
//  Created by Siddhant Jain on 16/04/19.
//  Copyright © 2019 Siddhant. All rights reserved.
//

import UIKit
class ReportProblemViewController: UIViewController {

    @IBOutlet var reportTextView: UITextView!
    @IBOutlet weak var emneTextField: UITextField!

    @IBAction func backTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        emneTextField.layer.borderColor = UIColor(red: 230/255, green: 232/255, blue: 237/255, alpha: 1.0).cgColor
        emneTextField.layer.cornerRadius = 4.0
        emneTextField.clipsToBounds = true
        emneTextField.layer.borderWidth = 0.5
        reportTextView.layer.cornerRadius = 4.0
        reportTextView.clipsToBounds = true
        reportTextView.layer.borderColor = UIColor(red: 230/255, green: 232/255, blue: 237/255, alpha: 1.0).cgColor
        reportTextView.layer.borderWidth = 0.5
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

