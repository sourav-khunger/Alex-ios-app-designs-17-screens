//
//  InViewController.swift
//  UIDemo
//
//  Created by Siddhant Jain on 18/04/19.
//  Copyright © 2019 Siddhant. All rights reserved.
//

import UIKit

class InViewController: UIViewController {

    @IBOutlet weak var inTableView: UITableView!
    @IBAction func backTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    var desc = ["Felleskostnad", "Lading elbil", "Felleskost"]
    var cost = ["1000 kr", "125 kr", "1000 kr"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        inTableView.tableFooterView = UIView()
        inTableView.estimatedRowHeight = 91
        inTableView.rowHeight = UITableView.automaticDimension
    }


    /*
     // MARK: - Navigation

     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */

}

extension InViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "DokViewController") else { return }
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension InViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return desc.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "dugnaderCell") as? dugnaderTableViewCell else {
            return UITableViewCell()
        }
        cell.backgroundColor = indexPath.row % 2 == 0 ? UIColor.white : UIColor(red: 244/255, green: 244/255, blue: 248/255, alpha: 1.0)
        cell.descLabel?.text = desc[indexPath.row]
        cell.typeLabel?.text = cost[indexPath.row]
        return cell
    }
}


