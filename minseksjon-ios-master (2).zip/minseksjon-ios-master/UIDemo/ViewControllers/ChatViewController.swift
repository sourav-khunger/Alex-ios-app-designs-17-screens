
//
//  ChatViewController.swift
//  UIDemo
//
//  Created by Siddhant Jain on 19/04/19.
//  Copyright © 2019 Siddhant. All rights reserved.
//

import UIKit


class SenderCell: UITableViewCell {

    @IBOutlet weak var labelMessage: UILabel!
    @IBOutlet weak var imageViewProfile: UIImageView!
    @IBOutlet weak var viewTopCorner: UIView!
    @IBOutlet weak var labelTime: UILabel!
}

class ReceiverCell: UITableViewCell {

}

class ChatViewController: UIViewController {

    @IBOutlet weak var chatTableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()

        chatTableView.tableFooterView = UIView()
    }

    @IBAction func backTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }


}

extension ChatViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {

        case 0:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "SenderCell") as? SenderCell else { return UITableViewCell() }
            cell.imageViewProfile.isHidden = false
            cell.labelMessage.text = "One of the best experience I had during my trip"
            cell.labelTime.text = "5m ago"
            cell.viewTopCorner.layer.cornerRadius = 0
            return cell
        case 1:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "SenderCell") as? SenderCell else { return UITableViewCell() }
            cell.imageViewProfile.isHidden = true
            cell.labelMessage.text = "I love surfing!"
            cell.labelTime.text = "4m ago"
            cell.viewTopCorner.layer.cornerRadius = 20
            return cell
        case 2:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "ReceiverCell") as? ReceiverCell else { return UITableViewCell() }

            return cell
        case 3:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "SenderCell") as? SenderCell else { return UITableViewCell() }
            cell.imageViewProfile.isHidden = false
            cell.labelMessage.text = "Absolutely!"
            cell.labelTime.text = "Just now"
            cell.viewTopCorner.layer.cornerRadius = 0
            return cell
        default:
            return UITableViewCell()
        }
    }


}
