//
//  OnViewController.swift
//  UIDemo
//
//  Created by Siddhant Jain on 18/04/19.
//  Copyright © 2019 Siddhant. All rights reserved.
//

import UIKit

class OnViewController: UIViewController {

    @IBOutlet weak var option1View: UIView!

    @IBOutlet weak var option2View: UIView!

    @IBOutlet weak var option3View: UIView!

    @IBAction func backTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        option1View.layer.borderColor = UIColor(red: 230/255, green: 232/255, blue: 237/255, alpha: 1.0).cgColor
        option1View.layer.cornerRadius = 8.0
        option1View.clipsToBounds = true
        option1View.layer.borderWidth = 2

        option2View.layer.borderColor = UIColor(red: 230/255, green: 232/255, blue: 237/255, alpha: 1.0).cgColor
        option2View.layer.cornerRadius = 8.0
        option2View.clipsToBounds = true
        option2View.layer.borderWidth = 2

        option3View.layer.borderColor = UIColor(red: 230/255, green: 232/255, blue: 237/255, alpha: 1.0).cgColor
        option3View.layer.cornerRadius = 8.0
        option3View.clipsToBounds = true
        option3View.layer.borderWidth = 2
    }


    /*
     // MARK: - Navigation

     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */

}
