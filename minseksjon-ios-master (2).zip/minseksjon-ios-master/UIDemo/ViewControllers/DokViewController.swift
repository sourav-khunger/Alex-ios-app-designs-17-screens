//
//  DokViewController.swift
//  UIDemo
//
//  Created by Siddhant Jain on 18/04/19.
//  Copyright © 2019 Siddhant. All rights reserved.
//

import UIKit

class DokViewController: UIViewController {

    var desc = ["Rabattavtaler", "Forsikringer", "Vedtekter"]

    @IBOutlet weak var dokTableView: UITableView!
    @IBAction func backTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        dokTableView.tableFooterView = UIView()
        dokTableView.estimatedRowHeight = 91
        dokTableView.rowHeight = UITableView.automaticDimension
    }


    /*
     // MARK: - Navigation

     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */

}

extension DokViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "VaskViewController") else { return }
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension DokViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return desc.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "dugnaderCell") as? dugnaderTableViewCell else {
            return UITableViewCell()
        }
        cell.backgroundColor = indexPath.row % 2 == 0 ? UIColor.white : UIColor(red: 244/255, green: 244/255, blue: 248/255, alpha: 1.0)
        cell.descLabel?.text = desc[indexPath.row]
        return cell
    }
}


